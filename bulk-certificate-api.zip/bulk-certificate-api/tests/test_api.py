import datetime as dt
import io
import zipfile

import pytest
from pypdf import PdfReader

from app import config, services, template
from app.models import Certificate, Job
from app.schemas import JobCreate
from app.validation import validate_recipient


def pdf_text(data: bytes) -> str:
    return PdfReader(io.BytesIO(data)).pages[0].extract_text()


def results(client, job_id, **params):
    return client.get(f"/jobs/{job_id}/certificates", params=params).json()


# ------------------------------------------------------------------ creating a job
def test_create_job_is_accepted_and_generates_all(client, payload):
    response = client.post("/jobs", json=payload())
    assert response.status_code == 202
    body = response.json()
    assert body["total"] == 3
    assert body["links"]["self"] == f"/jobs/{body['id']}"

    job = client.get(f"/jobs/{body['id']}").json()
    assert job["status"] == "completed"
    assert job["counts"] == {"pending": 0, "generated": 3, "failed": 0, "invalid": 0}
    assert job["progress_percent"] == 100.0
    assert job["finished_at"].endswith("Z")
    assert body["created_at"] == job["created_at"]  # same format before and after a reload


def test_issue_date_defaults_to_today(client, payload):
    body = payload()
    del body["issue_date"]
    job = client.post("/jobs", json=body).json()
    assert job["issue_date"] == dt.datetime.now(dt.timezone.utc).date().isoformat()


# ------------------------------------------------------------------ input validation
@pytest.mark.parametrize("change", [
    {"recipients": []},                     # nothing to generate
    {"course_name": "   "},                 # blank after trimming
    {"issuer_name": None},
    {"issue_date": "09/10/2026"},           # not ISO format
    {"recipients": ["just a string"]},      # not an object
    {"recipients": "nope"},
])
def test_bad_request_is_rejected_and_nothing_is_stored(client, payload, db, change):
    response = client.post("/jobs", json=payload(**change))
    assert response.status_code == 422
    assert db.query(Job).count() == 0


def test_too_many_recipients_is_rejected(client, payload, monkeypatch):
    monkeypatch.setattr(config, "MAX_RECIPIENTS_PER_JOB", 2)
    response = client.post("/jobs", json=payload())
    assert response.status_code == 422
    assert "at most 2" in response.json()["detail"]


def test_invalid_recipients_are_reported_and_valid_ones_still_generated(client, payload):
    recipients = [
        {"name": "Ada Lovelace", "email": "ada@example.com"},
        {"name": "Grace Hopper", "email": "not-an-email"},
        {"name": "   ", "email": "blank@example.com"},
        {"email": "missing-name@example.com"},
        {"name": "Ada Again", "email": " ADA@example.com "},   # duplicate, case-insensitive
        {"name": 12345, "email": None},                        # wrong types
        {"name": "x" * 101, "email": "long@example.com"},
        {"name": "Alan Turing", "email": "alan@example.com"},
    ]
    job = client.post("/jobs", json=payload(recipients)).json()
    job = client.get(f"/jobs/{job['id']}").json()

    assert job["status"] == "completed_with_errors"
    assert job["counts"] == {"pending": 0, "generated": 2, "failed": 0, "invalid": 6}

    items = results(client, job["id"])["items"]
    errors = {item["position"]: item["error"] for item in items}
    assert errors[1] is None and errors[8] is None
    assert errors[2] == "email is not a valid address"
    assert errors[3] == "name is required"
    assert errors[4] == "name is required"
    assert errors[5] == "duplicate email in this request"
    assert errors[6] == "name is required; email is required"
    assert errors[7] == "name must be at most 100 characters"
    assert all(item["download_url"] is None for item in items if item["status"] == "invalid")


def test_job_with_no_valid_recipient_fails(client, payload):
    job = client.post("/jobs", json=payload([{"name": "", "email": "x"}])).json()
    job = client.get(f"/jobs/{job['id']}").json()
    assert job["status"] == "failed"
    assert job["counts"]["invalid"] == 1
    assert client.get(f"/jobs/{job['id']}/download").status_code == 404


def test_validate_recipient_cleans_values():
    seen = set()
    name, email, errors = validate_recipient("  Ada   Lovelace ", " Ada@Example.com ", seen)
    assert (name, email, errors) == ("Ada Lovelace", "ada@example.com", [])
    assert seen == {"ada@example.com"}
    # An invalid entry must not reserve its email for a later, valid one.
    assert validate_recipient("", "bob@example.com", seen)[2] == ["name is required"]
    assert validate_recipient("Bob", "bob@example.com", seen)[2] == []


def test_control_characters_are_rejected_and_not_stored():
    name, email, errors = validate_recipient("A\x00B", "a@example.com", set())
    assert (name, errors) == ("AB", ["name contains control characters"])
    name, email, errors = validate_recipient("Ok", "x\x00y@example.com", set())
    assert (email, errors) == ("xy@example.com", ["email is not a valid address"])


# ------------------------------------------------------------------ certificate generation
def test_rendered_certificate_contains_the_recipient_details():
    pdf = template.render_certificate(
        certificate_id="abc-123", recipient_name="Zoë Šimková",
        course_name="Introduction to Python", issuer_name="Acme Academy",
        issue_date=dt.date(2026, 10, 9), signatory_name="Dana Lee",
        signatory_title="Program Director")
    assert pdf.startswith(b"%PDF")
    text = pdf_text(pdf)
    for expected in ("Certificate of Completion", "Zoë Šimková", "Introduction to Python",
                     "ACME ACADEMY", "October 09, 2026", "Dana Lee", "abc-123"):
        assert expected in text


def test_very_long_name_is_shrunk_not_cut_off():
    name = "W" * 100
    pdf = template.render_certificate(
        certificate_id="id", recipient_name=name, course_name="C",
        issuer_name="I", issue_date=dt.date(2026, 1, 1))
    assert name in pdf_text(pdf)


def test_each_recipient_gets_their_own_certificate(client, payload):
    job = client.post("/jobs", json=payload()).json()
    for item in results(client, job["id"])["items"]:
        response = client.get(item["download_url"])
        assert response.status_code == 200
        text = pdf_text(response.content)
        assert item["recipient_name"] in text
        assert item["id"] in text  # the ID printed on the PDF is the one in the API


# ------------------------------------------------------------------ status / progress
def test_job_moves_from_pending_to_completed(client, payload, db):
    # Create the job without running the worker, to observe the starting state.
    job = services.create_job(db, JobCreate(**payload()))
    status = client.get(f"/jobs/{job.id}").json()
    assert status["status"] == "pending"
    assert status["counts"]["pending"] == 3
    assert status["progress_percent"] == 0.0
    assert status["started_at"] is None
    assert client.get(f"/jobs/{job.id}/download").status_code == 409

    services.process_job(job.id)

    status = client.get(f"/jobs/{job.id}").json()
    assert status["status"] == "completed"
    assert status["counts"]["generated"] == 3
    assert status["progress_percent"] == 100.0


def test_progress_is_visible_while_the_job_is_running(client, payload, db, monkeypatch):
    job = services.create_job(db, JobCreate(**payload()))
    seen = []
    real_render = template.render_certificate

    def render_and_peek(**kwargs):
        seen.append(client.get(f"/jobs/{job.id}").json())
        return real_render(**kwargs)

    monkeypatch.setattr(template, "render_certificate", render_and_peek)
    services.process_job(job.id)

    assert [s["status"] for s in seen] == ["processing"] * 3
    assert [s["counts"]["generated"] for s in seen] == [0, 1, 2]
    assert [s["progress_percent"] for s in seen] == [0.0, 33.3, 66.7]


def test_unfinished_jobs_are_resumed(client, payload, db):
    job = services.create_job(db, JobCreate(**payload()))  # never processed
    assert services.resume_unfinished_jobs() == [job.id]
    assert client.get(f"/jobs/{job.id}").json()["status"] == "completed"
    assert services.resume_unfinished_jobs() == []


def test_unknown_ids_return_404(client):
    for url in ("/jobs/nope", "/jobs/nope/certificates", "/jobs/nope/download",
                "/certificates/nope", "/certificates/nope/download"):
        assert client.get(url).status_code == 404
    assert client.post("/jobs/nope/retry").status_code == 404


# ------------------------------------------------------------------ individual failure
@pytest.fixture
def grace_fails(monkeypatch):
    real_render = template.render_certificate

    def flaky(**kwargs):
        if kwargs["recipient_name"] == "Grace Hopper":
            raise RuntimeError("font exploded")
        return real_render(**kwargs)

    monkeypatch.setattr(template, "render_certificate", flaky)
    return real_render


def test_one_failure_does_not_stop_the_other_certificates(client, payload, grace_fails):
    job = client.post("/jobs", json=payload()).json()
    job = client.get(f"/jobs/{job['id']}").json()

    assert job["status"] == "completed_with_errors"
    assert job["counts"] == {"pending": 0, "generated": 2, "failed": 1, "invalid": 0}

    failed = results(client, job["id"], status="failed")["items"]
    assert len(failed) == 1
    assert failed[0]["recipient_name"] == "Grace Hopper"
    assert failed[0]["error"] == "RuntimeError: font exploded"
    assert failed[0]["download_url"] is None
    assert client.get(f"/certificates/{failed[0]['id']}/download").status_code == 409

    # The certificate after the failing one was still generated.
    generated = results(client, job["id"], status="generated")["items"]
    assert [c["recipient_name"] for c in generated] == ["Ada Lovelace", "Alan Turing"]


def test_retry_regenerates_only_the_failed_certificates(client, payload, grace_fails, monkeypatch):
    job = client.post("/jobs", json=payload()).json()
    before = {c["id"]: c["generated_at"] for c in results(client, job["id"])["items"]}

    monkeypatch.setattr(template, "render_certificate", grace_fails)  # fault fixed
    assert client.post(f"/jobs/{job['id']}/retry").status_code == 202

    job = client.get(f"/jobs/{job['id']}").json()
    assert job["status"] == "completed"
    assert job["counts"]["generated"] == 3
    for item in results(client, job["id"])["items"]:
        if before[item["id"]] is not None:
            assert item["generated_at"] == before[item["id"]]  # untouched


def test_job_fails_when_every_certificate_fails(client, payload, monkeypatch):
    def boom(**kwargs):
        raise RuntimeError("no disk")
    monkeypatch.setattr(template, "render_certificate", boom)
    job = client.post("/jobs", json=payload()).json()
    job = client.get(f"/jobs/{job['id']}").json()
    assert job["status"] == "failed"
    assert job["counts"]["failed"] == 3


# ------------------------------------------------------------------ retrieval
def test_list_certificates_filters_and_paginates(client, payload):
    recipients = [{"name": f"Person {i}", "email": f"p{i}@example.com"} for i in range(1, 6)]
    recipients.append({"name": "Bad", "email": "bad"})
    job = client.post("/jobs", json=payload(recipients)).json()

    page = results(client, job["id"], limit=2, offset=2)
    assert page["total"] == 6
    assert [c["position"] for c in page["items"]] == [3, 4]
    assert results(client, job["id"], status="invalid")["total"] == 1
    assert results(client, job["id"], status="generated")["total"] == 5
    assert client.get(f"/jobs/{job['id']}/certificates",
                      params={"status": "bogus"}).status_code == 422


def test_download_single_certificate(client, payload):
    job = client.post("/jobs", json=payload()).json()
    item = results(client, job["id"])["items"][0]

    details = client.get(f"/certificates/{item['id']}").json()
    assert details["status"] == "generated"
    assert details["recipient_email"] == "ada@example.com"

    response = client.get(details["download_url"])
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/pdf"
    assert "00001_Ada_Lovelace.pdf" in response.headers["content-disposition"]
    assert response.content.startswith(b"%PDF")


def test_download_all_as_zip(client, payload):
    recipients = [
        {"name": "Ada Lovelace", "email": "ada@example.com"},
        {"name": "Ada Lovelace", "email": "ada2@example.com"},     # same name
        {"name": "../../etc/passwd", "email": "evil@example.com"},  # hostile name
        {"name": "Nobody", "email": "invalid"},
    ]
    job = client.post("/jobs", json=payload(recipients)).json()
    response = client.get(f"/jobs/{job['id']}/download")
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/zip"

    archive = zipfile.ZipFile(io.BytesIO(response.content))
    assert archive.namelist() == [
        "00001_Ada_Lovelace.pdf", "00002_Ada_Lovelace.pdf", "00003_etc_passwd.pdf"]
    assert all(archive.read(n).startswith(b"%PDF") for n in archive.namelist())
    # The temporary ZIP is removed once it has been sent.
    assert list(config.STORAGE_DIR.glob("*.zip")) == []


def test_bulk_job_of_500_recipients(client, payload, db):
    recipients = [{"name": f"Person {i}", "email": f"p{i}@example.com"} for i in range(500)]
    job = client.post("/jobs", json=payload(recipients)).json()
    job = client.get(f"/jobs/{job['id']}").json()
    assert job["status"] == "completed"
    assert job["counts"]["generated"] == 500
    assert len(list((config.STORAGE_DIR / job["id"]).glob("*.pdf"))) == 500
    assert db.query(Certificate).count() == 500
