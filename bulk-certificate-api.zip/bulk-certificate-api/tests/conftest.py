"""Test setup: a throwaway database and storage folder, wiped between tests."""
import os
import shutil
import tempfile
from pathlib import Path

_TMP = Path(tempfile.mkdtemp(prefix="certgen-tests-"))
# Must be set before the app is imported, because config reads them at import.
os.environ["DATABASE_URL"] = f"sqlite:///{_TMP / 'test.db'}"
os.environ["STORAGE_DIR"] = str(_TMP / "storage")

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app import config  # noqa: E402
from app.database import Base, SessionLocal, engine  # noqa: E402
from app.main import app  # noqa: E402


@pytest.fixture(autouse=True)
def clean_state():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    shutil.rmtree(config.STORAGE_DIR, ignore_errors=True)
    config.STORAGE_DIR.mkdir(parents=True)
    yield


@pytest.fixture
def client():
    # Not used as a context manager, so the startup hook (which resumes
    # unfinished jobs in a thread) does not run and tests stay deterministic.
    # TestClient runs background tasks before `client.post` returns.
    return TestClient(app)


@pytest.fixture
def db():
    with SessionLocal() as session:
        yield session


@pytest.fixture
def payload():
    def make(recipients=None, **overrides):
        body = {
            "course_name": "Introduction to Python",
            "issuer_name": "Acme Academy",
            "issue_date": "2026-10-09",
            "signatory_name": "Dana Lee",
            "signatory_title": "Program Director",
            "recipients": recipients if recipients is not None else [
                {"name": "Ada Lovelace", "email": "ada@example.com"},
                {"name": "Grace Hopper", "email": "grace@example.com"},
                {"name": "Alan Turing", "email": "alan@example.com"},
            ],
        }
        body.update(overrides)
        return body
    return make
