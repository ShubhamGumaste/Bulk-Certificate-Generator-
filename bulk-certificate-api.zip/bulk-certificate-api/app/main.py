"""HTTP API.

Run:  uvicorn app.main:app --reload
Docs: http://127.0.0.1:8000/docs
"""
import tempfile
import threading
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal, Optional

from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from starlette.background import BackgroundTask

from . import config, services
from .database import Base, engine, get_db
from .models import Certificate, CertificateStatus, Job, JobStatus
from .schemas import CertificateOut, CertificatePage, JobCreate, JobOut


@asynccontextmanager
async def lifespan(_app: FastAPI):
    Base.metadata.create_all(engine)
    config.STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    # Pick up jobs a previous run did not finish, without delaying startup.
    threading.Thread(target=services.resume_unfinished_jobs, daemon=True).start()
    yield


app = FastAPI(
    title="Bulk Certificate Generator API",
    version="1.0.0",
    description="Submit a list of recipients, track the job, download the certificates.",
    lifespan=lifespan,
)


# ------------------------------------------------------------------ helpers
def _get_job(db: Session, job_id: str) -> Job:
    job = db.get(Job, job_id)
    if job is None:
        raise HTTPException(404, "Job not found.")
    return job


def _job_out(db: Session, job: Job) -> JobOut:
    counts = services.certificate_counts(db, job.id)
    total = sum(counts.values())
    done = total - counts[CertificateStatus.PENDING]
    return JobOut(
        id=job.id, status=job.status, error=job.error,
        course_name=job.course_name, issuer_name=job.issuer_name,
        issue_date=job.issue_date, created_at=job.created_at,
        started_at=job.started_at, finished_at=job.finished_at,
        total=total, counts=counts,
        progress_percent=round(100 * done / total, 1) if total else 100.0,
        links={
            "self": f"/jobs/{job.id}",
            "certificates": f"/jobs/{job.id}/certificates",
            "download": f"/jobs/{job.id}/download",
        },
    )


def _certificate_out(certificate: Certificate) -> CertificateOut:
    generated = certificate.status == CertificateStatus.GENERATED
    return CertificateOut(
        id=certificate.id, job_id=certificate.job_id, position=certificate.position,
        recipient_name=certificate.recipient_name,
        recipient_email=certificate.recipient_email,
        status=certificate.status, error=certificate.error,
        generated_at=certificate.generated_at,
        download_url=f"/certificates/{certificate.id}/download" if generated else None,
    )


# ------------------------------------------------------------------ jobs
@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/jobs", response_model=JobOut, status_code=202,
          summary="Submit a bulk certificate generation request")
def create_job(payload: JobCreate, background: BackgroundTasks,
               db: Session = Depends(get_db)):
    if len(payload.recipients) > config.MAX_RECIPIENTS_PER_JOB:
        raise HTTPException(
            422, f"A job can contain at most {config.MAX_RECIPIENTS_PER_JOB} recipients; "
                 f"received {len(payload.recipients)}.")
    job = services.create_job(db, payload)
    # Runs after the response has been sent, so the client is not kept waiting.
    background.add_task(services.process_job, job.id)
    return _job_out(db, job)


@app.get("/jobs/{job_id}", response_model=JobOut, summary="Job status and progress")
def get_job(job_id: str, db: Session = Depends(get_db)):
    return _job_out(db, _get_job(db, job_id))


@app.get("/jobs/{job_id}/certificates", response_model=CertificatePage,
         summary="Per-recipient results of a job")
def list_certificates(
    job_id: str,
    status: Optional[Literal["pending", "generated", "failed", "invalid"]] = None,
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
):
    _get_job(db, job_id)
    conditions = [Certificate.job_id == job_id]
    if status:
        conditions.append(Certificate.status == status)
    total = db.scalar(select(func.count()).select_from(Certificate).where(*conditions))
    rows = db.scalars(
        select(Certificate).where(*conditions)
        .order_by(Certificate.position).limit(limit).offset(offset)
    ).all()
    return CertificatePage(total=total, limit=limit, offset=offset,
                           items=[_certificate_out(row) for row in rows])


@app.get("/jobs/{job_id}/download", response_class=FileResponse,
         summary="Download all generated certificates of a job as a ZIP")
def download_job(job_id: str, db: Session = Depends(get_db)):
    job = _get_job(db, job_id)
    if job.status not in JobStatus.FINISHED:
        raise HTTPException(409, f"Job is still {job.status}. Try again when it has finished.")
    config.STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    handle, name = tempfile.mkstemp(suffix=".zip", dir=config.STORAGE_DIR)
    zip_path = Path(name)
    try:
        with open(handle, "wb") as zip_file:
            added = services.write_zip(db, job, zip_file)
    except Exception:
        zip_path.unlink(missing_ok=True)
        raise
    if added == 0:
        zip_path.unlink(missing_ok=True)
        raise HTTPException(404, "This job has no generated certificates.")
    return FileResponse(
        zip_path, media_type="application/zip", filename=f"certificates-{job.id}.zip",
        background=BackgroundTask(zip_path.unlink, missing_ok=True),  # delete after sending
    )


@app.post("/jobs/{job_id}/retry", response_model=JobOut, status_code=202,
          summary="Retry the certificates that failed to generate")
def retry_job(job_id: str, background: BackgroundTasks, db: Session = Depends(get_db)):
    job = _get_job(db, job_id)
    if job.status not in JobStatus.FINISHED:
        raise HTTPException(409, f"Job is still {job.status}.")
    if services.retry_failed(db, job):
        background.add_task(services.process_job, job.id)
    return _job_out(db, job)


# ------------------------------------------------------------------ certificates
@app.get("/certificates/{certificate_id}", response_model=CertificateOut,
         summary="Details of one certificate")
def get_certificate(certificate_id: str, db: Session = Depends(get_db)):
    certificate = db.get(Certificate, certificate_id)
    if certificate is None:
        raise HTTPException(404, "Certificate not found.")
    return _certificate_out(certificate)


@app.get("/certificates/{certificate_id}/download", response_class=FileResponse,
         summary="Download one certificate as a PDF")
def download_certificate(certificate_id: str, db: Session = Depends(get_db)):
    certificate = db.get(Certificate, certificate_id)
    if certificate is None:
        raise HTTPException(404, "Certificate not found.")
    if certificate.status != CertificateStatus.GENERATED:
        raise HTTPException(409, f"Certificate is {certificate.status}; there is no file to download.")
    path = config.STORAGE_DIR / certificate.file_path
    if not path.is_file():
        raise HTTPException(404, "Certificate file is missing from storage.")
    return FileResponse(path, media_type="application/pdf",
                        filename=services.download_name(certificate))
