"""Request and response shapes."""
import datetime as dt
from typing import Annotated, Any, Dict, List, Optional

from pydantic import AfterValidator, BaseModel, ConfigDict, Field


def _as_utc(value: dt.datetime) -> dt.datetime:
    """Timestamps are stored in UTC, but SQLite returns them without a timezone.
    Re-attach it so every response carries an explicit offset ("...Z")."""
    return value.replace(tzinfo=dt.timezone.utc) if value.tzinfo is None else value


UtcDatetime = Annotated[dt.datetime, AfterValidator(_as_utc)]


class RecipientIn(BaseModel):
    """One recipient.

    Fields are typed loosely on purpose: a bad name or email must not reject the
    whole request. Each recipient is checked in validation.py and a bad one is
    recorded as an `invalid` entry on the job instead.
    """
    name: Any = Field(None, examples=["Ada Lovelace"])
    email: Any = Field(None, examples=["ada@example.com"])


class JobCreate(BaseModel):
    """Job-level fields are strict: if these are wrong, no certificate could be
    correct, so the request is rejected with 422."""
    model_config = ConfigDict(str_strip_whitespace=True)

    course_name: str = Field(min_length=1, max_length=150, examples=["Introduction to Python"])
    issuer_name: str = Field(min_length=1, max_length=100, examples=["Acme Academy"])
    issue_date: Optional[dt.date] = Field(None, description="Defaults to today.")
    signatory_name: Optional[str] = Field(None, max_length=80)
    signatory_title: Optional[str] = Field(None, max_length=80)
    recipients: List[RecipientIn] = Field(min_length=1)


class JobOut(BaseModel):
    id: str
    status: str
    error: Optional[str]
    course_name: str
    issuer_name: str
    issue_date: dt.date
    created_at: UtcDatetime
    started_at: Optional[UtcDatetime]
    finished_at: Optional[UtcDatetime]
    total: int
    counts: Dict[str, int]    # pending / generated / failed / invalid
    progress_percent: float   # share of recipients that reached a final state
    links: Dict[str, str]


class CertificateOut(BaseModel):
    id: str
    job_id: str
    position: int
    recipient_name: Optional[str]
    recipient_email: Optional[str]
    status: str
    error: Optional[str]
    generated_at: Optional[UtcDatetime]
    download_url: Optional[str]  # set only when status is "generated"


class CertificatePage(BaseModel):
    total: int
    limit: int
    offset: int
    items: List[CertificateOut]
