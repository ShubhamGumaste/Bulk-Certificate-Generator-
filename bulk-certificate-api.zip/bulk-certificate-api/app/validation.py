"""Per-recipient validation.

Returns the cleaned values plus a list of problems. An empty list means the
recipient is valid.
"""
import re
from typing import Any, List, Optional, Set, Tuple

MAX_NAME_LENGTH = 100
MAX_EMAIL_LENGTH = 254

_CONTROL_CHARS = re.compile(r"[\x00-\x1f\x7f]")
# Deliberately simple: something@something.something with no spaces. Full RFC
# validation rejects real addresses; the aim is to catch obvious mistakes.
_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def validate_recipient(
    name: Any, email: Any, seen_emails: Set[str]
) -> Tuple[Optional[str], Optional[str], List[str]]:
    """`seen_emails` holds the valid emails already accepted in this request and
    is updated here, so a repeated address is reported as a duplicate."""
    errors: List[str] = []

    if not isinstance(name, str) or not name.strip():
        errors.append("name is required")
        clean_name = _display(name)
    else:
        clean_name = " ".join(name.split())  # trim and collapse whitespace
        if len(clean_name) > MAX_NAME_LENGTH:
            errors.append(f"name must be at most {MAX_NAME_LENGTH} characters")
        if _CONTROL_CHARS.search(clean_name):
            errors.append("name contains control characters")

    if not isinstance(email, str) or not email.strip():
        errors.append("email is required")
        clean_email = _display(email)
    else:
        clean_email = email.strip().lower()
        if (len(clean_email) > MAX_EMAIL_LENGTH or not _EMAIL.match(clean_email)
                or _CONTROL_CHARS.search(clean_email)):
            errors.append("email is not a valid address")
        elif clean_email in seen_emails:
            errors.append("duplicate email in this request")
        elif not errors:
            seen_emails.add(clean_email)

    return _storable(clean_name), _storable(clean_email), errors


def _display(value: Any) -> Optional[str]:
    """Bad input, shortened so it fits in the database for the error report."""
    if value is None:
        return None
    return str(value).strip()[:255] or None


def _storable(value: Optional[str]) -> Optional[str]:
    """Remove control characters before storing. They are already reported as
    an error above; some databases (PostgreSQL) refuse NUL bytes in text."""
    return _CONTROL_CHARS.sub("", value) if value else value
