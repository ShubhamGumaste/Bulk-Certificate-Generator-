"""Database tables: one Job has many Certificates (one per submitted recipient)."""
import datetime as dt
import uuid
from typing import List, Optional

from sqlalchemy import Date, DateTime, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


class JobStatus:
    PENDING = "pending"                              # accepted, not started
    PROCESSING = "processing"                        # worker is generating
    COMPLETED = "completed"                          # every recipient got a certificate
    COMPLETED_WITH_ERRORS = "completed_with_errors"  # some generated, some did not
    FAILED = "failed"                                # nothing was generated

    FINISHED = (COMPLETED, COMPLETED_WITH_ERRORS, FAILED)


class CertificateStatus:
    PENDING = "pending"      # valid, waiting to be generated
    GENERATED = "generated"  # PDF exists and can be downloaded
    FAILED = "failed"        # valid data, but generation raised an error (retryable)
    INVALID = "invalid"      # recipient data failed validation (never generated)


def _uuid() -> str:
    return str(uuid.uuid4())


def utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


class Job(Base):
    __tablename__ = "jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    status: Mapped[str] = mapped_column(String(32), default=JobStatus.PENDING, index=True)
    error: Mapped[Optional[str]] = mapped_column(Text)  # only for a job-level crash

    # Certificate details shared by every recipient in the job.
    course_name: Mapped[str] = mapped_column(String(150))
    issuer_name: Mapped[str] = mapped_column(String(100))
    issue_date: Mapped[dt.date] = mapped_column(Date)
    signatory_name: Mapped[Optional[str]] = mapped_column(String(80))
    signatory_title: Mapped[Optional[str]] = mapped_column(String(80))

    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    started_at: Mapped[Optional[dt.datetime]] = mapped_column(DateTime(timezone=True))
    finished_at: Mapped[Optional[dt.datetime]] = mapped_column(DateTime(timezone=True))

    certificates: Mapped[List["Certificate"]] = relationship(
        back_populates="job", cascade="all, delete-orphan")


class Certificate(Base):
    __tablename__ = "certificates"
    # The worker and the status endpoint both filter by (job_id, status).
    __table_args__ = (Index("ix_certificates_job_status", "job_id", "status"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    job_id: Mapped[str] = mapped_column(ForeignKey("jobs.id", ondelete="CASCADE"))
    position: Mapped[int] = mapped_column(Integer)  # 1-based index in the request

    # Stored as submitted (trimmed), even when invalid, so the client can see
    # which entry a validation error refers to.
    recipient_name: Mapped[Optional[str]] = mapped_column(String(255))
    recipient_email: Mapped[Optional[str]] = mapped_column(String(255))

    status: Mapped[str] = mapped_column(String(16), default=CertificateStatus.PENDING)
    error: Mapped[Optional[str]] = mapped_column(Text)
    file_path: Mapped[Optional[str]] = mapped_column(String(255))  # relative to STORAGE_DIR
    generated_at: Mapped[Optional[dt.datetime]] = mapped_column(DateTime(timezone=True))

    job: Mapped[Job] = relationship(back_populates="certificates")
