"""The predefined certificate template.

One fixed landscape A4 design, drawn with ReportLab. `render_certificate` is a
pure function (values in, PDF bytes out): it touches neither the database nor
the disk, which keeps it easy to test and to replace.
"""
import datetime as dt
import io
from pathlib import Path
from typing import Optional

from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.utils import simpleSplit
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

# The built-in PDF fonts only cover Western European characters, so a Unicode
# font is bundled to render names such as "Zoë Šimková" correctly.
_FONTS = Path(__file__).parent / "fonts"
pdfmetrics.registerFont(TTFont("Cert", str(_FONTS / "DejaVuSans.ttf")))
pdfmetrics.registerFont(TTFont("Cert-Bold", str(_FONTS / "DejaVuSans-Bold.ttf")))

TITLE = "Certificate of Completion"
ACCENT = HexColor("#1F3A5F")
INK = HexColor("#222222")
MUTED = HexColor("#666666")


def render_certificate(
    *,
    certificate_id: str,
    recipient_name: str,
    course_name: str,
    issuer_name: str,
    issue_date: dt.date,
    signatory_name: Optional[str] = None,
    signatory_title: Optional[str] = None,
) -> bytes:
    width, height = landscape(A4)
    center = width / 2
    text_width = width - 160

    buffer = io.BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=(width, height))
    pdf.setTitle(f"{TITLE} - {recipient_name}")
    pdf.setAuthor(issuer_name)

    # Border
    pdf.setStrokeColor(ACCENT)
    pdf.setLineWidth(6)
    pdf.rect(24, 24, width - 48, height - 48)
    pdf.setLineWidth(1)
    pdf.rect(36, 36, width - 72, height - 72)

    # Issuer and title
    pdf.setFillColor(MUTED)
    pdf.setFont("Cert", 12)
    pdf.drawCentredString(center, height - 85, issuer_name.upper())
    pdf.setFillColor(ACCENT)
    pdf.setFont("Cert-Bold", 36)
    pdf.drawCentredString(center, height - 140, TITLE)

    # Recipient name, shrunk to fit so a long name is never cut off
    pdf.setFillColor(MUTED)
    pdf.setFont("Cert", 14)
    pdf.drawCentredString(center, height - 190, "This certificate is presented to")
    pdf.setFillColor(INK)
    pdf.setFont("Cert-Bold", _fit_size(recipient_name, "Cert-Bold", 42, text_width))
    pdf.drawCentredString(center, height - 250, recipient_name)
    pdf.setStrokeColor(ACCENT)
    pdf.line(center - 200, height - 266, center + 200, height - 266)

    # Course
    pdf.setFillColor(MUTED)
    pdf.setFont("Cert", 14)
    pdf.drawCentredString(center, height - 300, "for successfully completing")
    pdf.setFillColor(INK)
    pdf.setFont("Cert-Bold", 18)
    y = height - 330
    for line in simpleSplit(course_name, "Cert-Bold", 18, text_width - 60)[:3]:
        pdf.drawCentredString(center, y, line)
        y -= 24

    # Date (left) and signature (right)
    baseline = 105
    pdf.setStrokeColor(MUTED)
    columns = (
        (width * 0.27, issue_date.strftime("%B %d, %Y"), "Date"),
        (width * 0.73, signatory_name or "", signatory_title or "Authorized Signature"),
    )
    for x, value, label in columns:
        pdf.line(x - 95, baseline, x + 95, baseline)
        pdf.setFillColor(INK)
        pdf.setFont("Cert", 12)
        pdf.drawCentredString(x, baseline + 8, value)
        pdf.setFillColor(MUTED)
        pdf.setFont("Cert", 10)
        pdf.drawCentredString(x, baseline - 15, label)

    pdf.setFont("Cert", 8)
    pdf.drawCentredString(center, 50, f"Certificate ID: {certificate_id}")

    pdf.showPage()
    pdf.save()
    return buffer.getvalue()


def _fit_size(text: str, font: str, size: float, max_width: float) -> float:
    """Largest font size up to `size` at which `text` fits in `max_width`."""
    text_width = pdfmetrics.stringWidth(text, font, size)
    if text_width <= max_width:
        return size
    return max(8.0, size * max_width / text_width)
