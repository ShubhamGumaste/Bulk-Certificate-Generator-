"""Settings, read once from environment variables."""
import os
from pathlib import Path

# Any SQLAlchemy URL works, e.g. postgresql+psycopg://user:pass@host/dbname
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./certificates.db")

# Generated PDFs are written here as <job_id>/<certificate_id>.pdf
STORAGE_DIR = Path(os.getenv("STORAGE_DIR", "./storage"))

# Upper bound on one request, so a single call cannot queue unbounded work.
MAX_RECIPIENTS_PER_JOB = int(os.getenv("MAX_RECIPIENTS_PER_JOB", "10000"))
