"""Business logic: creating jobs, generating certificates, summarising progress.

Nothing here depends on FastAPI. `process_job(job_id)` is the unit of background
work, so moving to a task queue later means calling this same function from a
queue worker.
"""
import logging
import re
import zipfile
from pathlib import Path
from typing import Dict, List

from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

from . import config, template
from .database import SessionLocal
from .models import Certificate, CertificateStatus, Job, JobStatus, utcnow
from .schemas import JobCreate
from .validation import validate_recipient

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------ create
def create_job(db: Session, payload: JobCreate) -> Job:
    """Store the job and one row per recipient. Invalid recipients are stored
    too (status `invalid`, with the reason) so the client gets a full report."""
    job = Job(
        course_name=payload.course_name,
        issuer_name=payload.issuer_name,
        issue_date=payload.issue_date or utcnow().date(),
        signatory_name=payload.signatory_name,
        signatory_title=payload.signatory_title,
    )
    seen_emails: set = set()
    for position, recipient in enumerate(payload.recipients, start=1):
        name, email, errors = validate_recipient(recipient.name, recipient.email, seen_emails)
        job.certificates.append(Certificate(
            position=position,
            recipient_name=name[:255] if name else None,
            recipient_email=email[:255] if email else None,
            status=CertificateStatus.INVALID if errors else CertificateStatus.PENDING,
            error="; ".join(errors) or None,
        ))
    db.add(job)
    db.commit()
    return job


# ------------------------------------------------------------------ process
def process_job(job_id: str) -> None:
    """Generate every pending certificate of a job.

    Runs outside a request, so it opens its own session. It only picks up
    `pending` rows, which makes it safe to run again after a crash or a retry:
    certificates that already exist are not regenerated.
    """
    with SessionLocal() as db:
        job = db.get(Job, job_id)
        if job is None:
            return
        try:
            job.status = JobStatus.PROCESSING
            job.started_at = job.started_at or utcnow()
            job.finished_at = None
            db.commit()

            pending = db.scalars(
                select(Certificate)
                .where(Certificate.job_id == job_id,
                       Certificate.status == CertificateStatus.PENDING)
                .order_by(Certificate.position)
            ).all()
            for certificate in pending:
                _generate_one(db, job, certificate)

            counts = certificate_counts(db, job_id)
            if counts[CertificateStatus.GENERATED] == 0:
                job.status = JobStatus.FAILED
            elif counts[CertificateStatus.FAILED] or counts[CertificateStatus.INVALID]:
                job.status = JobStatus.COMPLETED_WITH_ERRORS
            else:
                job.status = JobStatus.COMPLETED
        except Exception as exc:  # e.g. the database became unreachable
            logger.exception("Job %s crashed", job_id)
            db.rollback()
            job.status = JobStatus.FAILED
            job.error = f"{type(exc).__name__}: {exc}"[:500]
        job.finished_at = utcnow()
        db.commit()


def _generate_one(db: Session, job: Job, certificate: Certificate) -> None:
    """Generate one certificate. Any error is recorded on that certificate and
    swallowed, so one failure never stops the rest of the job."""
    try:
        pdf_bytes = template.render_certificate(
            certificate_id=certificate.id,
            recipient_name=certificate.recipient_name,
            course_name=job.course_name,
            issuer_name=job.issuer_name,
            issue_date=job.issue_date,
            signatory_name=job.signatory_name,
            signatory_title=job.signatory_title,
        )
        relative_path = Path(job.id) / f"{certificate.id}.pdf"
        full_path = config.STORAGE_DIR / relative_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_bytes(pdf_bytes)

        certificate.file_path = str(relative_path)
        certificate.status = CertificateStatus.GENERATED
        certificate.generated_at = utcnow()
        certificate.error = None
    except Exception as exc:
        logger.exception("Certificate %s failed", certificate.id)
        certificate.status = CertificateStatus.FAILED
        certificate.error = f"{type(exc).__name__}: {exc}"[:500]
    # Commit per certificate so progress is visible while the job is running.
    db.commit()


def retry_failed(db: Session, job: Job) -> int:
    """Put `failed` certificates back to `pending`. Returns how many were reset.
    `invalid` ones are left alone: retrying cannot fix bad input."""
    result = db.execute(
        update(Certificate)
        .where(Certificate.job_id == job.id,
               Certificate.status == CertificateStatus.FAILED)
        .values(status=CertificateStatus.PENDING, error=None)
    )
    if result.rowcount:
        job.status = JobStatus.PENDING
        job.error = None
    db.commit()
    return result.rowcount


def resume_unfinished_jobs() -> List[str]:
    """Called at startup. Background work lives in this process, so a restart
    interrupts it; the database still knows which jobs were not finished."""
    with SessionLocal() as db:
        job_ids = db.scalars(
            select(Job.id)
            .where(Job.status.in_([JobStatus.PENDING, JobStatus.PROCESSING]))
            .order_by(Job.created_at)
        ).all()
    for job_id in job_ids:
        process_job(job_id)
    return list(job_ids)


# ------------------------------------------------------------------ read
def certificate_counts(db: Session, job_id: str) -> Dict[str, int]:
    """Number of certificates per status, always derived from the rows
    themselves so the summary cannot drift from the detail."""
    counts = {
        CertificateStatus.PENDING: 0,
        CertificateStatus.GENERATED: 0,
        CertificateStatus.FAILED: 0,
        CertificateStatus.INVALID: 0,
    }
    rows = db.execute(
        select(Certificate.status, func.count())
        .where(Certificate.job_id == job_id)
        .group_by(Certificate.status)
    ).all()
    for status, count in rows:
        counts[status] = count
    return counts


def write_zip(db: Session, job: Job, destination) -> int:
    """Write all generated certificates of a job to a ZIP file. Returns how
    many were added."""
    certificates = db.scalars(
        select(Certificate)
        .where(Certificate.job_id == job.id,
               Certificate.status == CertificateStatus.GENERATED)
        .order_by(Certificate.position)
    ).all()
    added = 0
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
        for certificate in certificates:
            source = config.STORAGE_DIR / certificate.file_path
            if source.is_file():
                archive.write(source, download_name(certificate))
                added += 1
    return added


def download_name(certificate: Certificate) -> str:
    """Readable file name. The position prefix keeps names unique when two
    recipients share a name, and the slug strips anything unsafe in a path."""
    slug = re.sub(r"[^\w\-]+", "_", certificate.recipient_name or "").strip("_")[:60]
    return f"{certificate.position:05d}_{slug or 'recipient'}.pdf"
